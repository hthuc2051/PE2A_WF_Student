/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student;

/**
 *
 * @author ADMIN
 */
public class Cabinet {

    //StartList
    // Declare ArrayList or Array here
    
    //EndList
    
    public void add() {
        // Print the object details after adding

    }

    public boolean checkDuplicatedId(String id) {
        // Your code here
        
        return true;
    }

    public void update() {
        // Print the object details after updating name/model and price

    }

    public void search() {
        // Print the object details after searching

    }
    
    public void remove() {
        // Print the object details after removing

    }

    public void sort() {
        // Print the object details after sorting

    }
}
