﻿using Practical_CSharp.Student.DBUtil;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practical_CSharp.Student.Repository
{
   public class AdminDAO
    {
        public static Boolean CheckLogin(String username,String password)
        {
            var getConnection = Connection.GetConnection();
            SqlDataReader rd = null;
            try
            {
                if (getConnection.State == ConnectionState.Closed)
                {
                    getConnection.Open();
                }
                SqlCommand cmd = new SqlCommand("Select * from Admin where " +
                    "Id = @username and Password = @password", getConnection);
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password);
                rd = cmd.ExecuteReader();
                if (rd.Read())
                {
                    if (rd.GetBoolean(3) == true)
                    {
                        return true;
                    }
                    return false;
                }
                else
                {

                    return false;
                }
            }
            catch (Exception e)
            {

                throw;
            }
            finally
            {
                rd.Close();
            }

        }
    }
}
