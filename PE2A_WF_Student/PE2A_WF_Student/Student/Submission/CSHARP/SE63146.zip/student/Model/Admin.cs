﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practical_CSharp.Student.Model
{
   public class Admin
    {
        public String Id { get; set; }
        public String Password { get; set; }
        public String Fullname { get; set; }
        public Boolean IsAdmin { get; set; }
    }
}
